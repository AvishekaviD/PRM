create table IN0405_data
(
best_mobile_number_hash varchar(255)
,UpdatedBrand_Name varchar(255)
,source varchar(255)
,lastinteractiondate date
,gender varchar(255)
);


--bt 

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,UpdatedBrand_Name,lastinteractiondate)
select distinct best_mobile_number_hash ,'BT',b.campaign_brand,max(cast(entry_date as date))
from PRM.bt_entry a inner join PRM.bt_campaign b on a.campaign_id=b.campaign_id
where b.country_code='IN'
and (lower(b.campaign_brand) like '%close%' or lower(b.campaign_brand) like '%corne%' or lower(b.campaign_brand) like '%pond%' or lower(b.campaign_brand) like '%sunsi%')
group by best_mobile_number_hash ,b.campaign_brand;




--cl

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'CL',brand,max(cast(SUBSTR(posting_date,7,4)||'-'||SUBSTR(posting_date,4,2)||'-'||SUBSTR(posting_date,1,2) as date))
from PRM.cl_call
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash,'CL',brand,max(cast(SUBSTR(posting_date,7,4)||'-'||SUBSTR(posting_date,4,2)||'-'||SUBSTR(posting_date,1,2) as date))
from PRM.cl_call_pti748
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'CL',brand,max(cast(SUBSTR(posting_date,7,4)||'-'||SUBSTR(posting_date,4,2)||'-'||SUBSTR(posting_date,1,2) as date))
from PRM.cl_call_till_dec2015
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'CL',brand,max(cast(SUBSTR(posting_date,7,4)||'-'||SUBSTR(posting_date,4,2)||'-'||SUBSTR(posting_date,1,2) as date))
from PRM.cl_calls_aug_sep_2014
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;


insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash,'CL',brand,max(cast(posting_date as date))
from PRM.cl_calls_01Mar2014_30jun2014
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash,'CL',cl_brand,max(cast(cl_call_date as date))
from PRM.cl_calls_2012_2013
where (lower(cl_brand) like '%close%' or lower(cl_brand) like '%corne%' or lower(cl_brand) like '%pond%' or lower(cl_brand) like '%sunsi%')
group by best_mobile_number_hash ,cl_brand;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'CL',brand,max(cast(posting_date as date))
from PRM.cl_calls_2013_2014
where (lower(brand) like '%close%' or lower(brand) like '%corne%' or lower(brand) like '%pond%' or lower(brand) like '%sunsi%')
group by best_mobile_number_hash ,brand;



--h2h 
insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'H2H',updatedbrand_name,max(cast(SUBSTR(interaction_date,1,10) as date))
from PRM.h2h_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where interaction_date  NOT LIKE ALL ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%','%/%')and LENGTH(interaction_date)>0
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by  best_mobile_number_hash,updatedbrand_name;


insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'H2H',updatedbrand_name,max(cast(SUBSTR(geo_timestamp,1,10) as date))
from PRM.mindtree_data a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where geo_timestamp  NOT LIKE ALL ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%','%/%')
and LENGTH(geo_timestamp)>0
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'H2H',updatedbrand_name
,max(cast(SUBSTR(interaction_date,7,4)||'-'||SUBSTR(interaction_date,4,2)||'-'||SUBSTR(interaction_date,1,2) as date))
from PRM.h2h_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where interaction_date  NOT LIKE ALL ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%')
and  interaction_date LIKE ANY ('%/%') and LENGTH(interaction_date)>0
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select best_mobile_number_hash ,'H2H',updatedbrand_name
,max(cast(SUBSTR(geo_timestamp,7,4)||'-'||SUBSTR(geo_timestamp,4,2)||'-'||SUBSTR(geo_timestamp,1,2) as date))
from PRM.mindtree_data a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where geo_timestamp  NOT LIKE ALL ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%')
and  geo_timestamp LIKE ANY ('%/%') and LENGTH(geo_timestamp)>0
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'H2H',updatedbrand_name,max(cast(("year"||'-'||"Month"||'-'||"Day") as date))
from (
select distinct  best_mobile_number_hash ,c.brand,updatedbrand_name,
Case
when substr(geo_timestamp,8,2)='12' then '2012' when substr(geo_timestamp,8,2)='13' then '2013'
when substr(geo_timestamp,8,2)='14' then '2014' when substr(geo_timestamp,8,3)='15' then '2015'
when substr(geo_timestamp,8,3)='16' then '2016' when substr(geo_timestamp,8,3)='17' then '2017'
when substr(geo_timestamp,8,3)='18' then '2018'when substr(geo_timestamp,8,3)='19' then '2019' end "Year",
case 
when substr(geo_timestamp,4,3)='Jan' then '01' when substr(geo_timestamp,4,3)='Feb' then '02'
when substr(geo_timestamp,4,3)='Mar' then '03' when substr(geo_timestamp,4,3)='Apr' then '04'
when substr(geo_timestamp,4,3)='May' then '05' when substr(geo_timestamp,4,3)='Jun' then '06'
when substr(geo_timestamp,4,3)='Jul' then '07' when substr(geo_timestamp,4,3)='Aug' then '08'
when substr(geo_timestamp,4,3)='Sep' then '09' when substr(geo_timestamp,4,3)='Oct' then '10'
when substr(geo_timestamp,4,3)='Nov' then '11'when substr(geo_timestamp,4,3)='Dec' then '12' end "Month"
,substr(geo_timestamp,1,2) "Day"
from PRM.mindtree_data c
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on c.Brand=b.Brand_name
where  geo_timestamp   LIKE ANY ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%')
and LENGTH(geo_timestamp)>0
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
) as a group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'H2H',updatedbrand_name,max(cast(("year"||'-'||"Month"||'-'||"Day") as date))
from (
select distinct  best_mobile_number_hash ,c.brand,updatedbrand_name,
Case
when substr(interaction_date,8,2)='12' then '2012' when substr(interaction_date,8,2)='13' then '2013'
when substr(interaction_date,8,2)='14' then '2014' when substr(interaction_date,8,3)='15' then '2015'
when substr(interaction_date,8,3)='16' then '2016' when substr(interaction_date,8,3)='17' then '2017'
when substr(interaction_date,8,3)='18' then '2018'when substr(interaction_date,8,3)='19' then '2019' end "Year",
case 
when substr(interaction_date,4,3)='Jan' then '01' when substr(interaction_date,4,3)='Feb' then '02'
when substr(interaction_date,4,3)='Mar' then '03' when substr(interaction_date,4,3)='Apr' then '04'
when substr(interaction_date,4,3)='May' then '05' when substr(interaction_date,4,3)='Jun' then '06'
when substr(interaction_date,4,3)='Jul' then '07' when substr(interaction_date,4,3)='Aug' then '08'
when substr(interaction_date,4,3)='Sep' then '09' when substr(interaction_date,4,3)='Oct' then '10'
when substr(interaction_date,4,3)='Nov' then '11'when substr(interaction_date,4,3)='Dec' then '12' end "Month"
,substr(interaction_date,1,2) "Day"
from PRM.h2h_transaction c
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on c.Brand=b.Brand_name
where  interaction_date   LIKE ANY ('%Jan%','%Feb%','%Mar%','%Apr%','%May%'
,'%Jun%','%Jul%','%Aug%','%Sep%','%Oct%','%Nov%','%Dec%')
and LENGTH(interaction_date)>0 
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
) as a group by best_mobile_number_hash,updatedbrand_name;


--dl all campaigns 

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name,max(cast(entry_date as date))
from PRM.dl_all_campaigns  a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where entry_date is not null
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

---one97 tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(date_of_interaction,7,4)||'-'||SUBSTR(date_of_interaction,4,2)||'-'||SUBSTR(date_of_interaction,1,2) as date))
from PRM.dl197_transaction  a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where date_of_interaction like '%/%' and LENGTH(date_of_interaction)>='10'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash,'DL',updatedbrand_name
,max(cast(SUBSTR(date_of_interaction,7,4)||'-'||SUBSTR(date_of_interaction,4,2)||'-'||SUBSTR(date_of_interaction,1,2) as date))
from PRM.dl197_transaction  a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where date_of_interaction like '%-%' and LENGTH(date_of_interaction)>='10'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(b.date_of_interaction1 as date))
from PRM.dl197_transaction a inner join GAIN_THEORY.PRMActiveInactiveDateMapping b
on a.date_of_interaction=b.date_of_interaction
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on a.Brand_name=c.Brand_name
where LENGTH(a.date_of_interaction)<'10'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;




---ozonetel tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_of_interaction as date))
from PRM.dloz_tier3 a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

---dlts tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(substr(datetime_of_interaction ,1,10) as date))
from PRM.dlts_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where datetime_of_interaction like '%-%'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(datetime_of_interaction,7,4)||'-'||SUBSTR(datetime_of_interaction,4,2)||'-'||SUBSTR(datetime_of_interaction,1,2) as date))
from PRM.dlts_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where datetime_of_interaction like '%/%' and datetime_of_interaction not like '%Date/Time%'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;


--dlzd tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(datetime_of_interaction,7,4)||'-'||SUBSTR(datetime_of_interaction,4,2)||'-'||SUBSTR(datetime_of_interaction,1,2) as date))
from PRM.dlzd_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where datetime_of_interaction like '%/%' and datetime_of_interaction not like '%Date/Time%'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(substr(datetime_of_interaction ,1,10) as date))
from PRM.dlzd_transaction a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand=b.Brand_name
where datetime_of_interaction like '%-%'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

-----imi tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_of_interaction as date))
from PRM.imimobile_tier3 a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

---mgage tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(date_of_interaction,7,4)||'-'||SUBSTR(date_of_interaction,4,2)||'-'||SUBSTR(date_of_interaction,1,2) as date))
from PRM.mgage_tier3 a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where LENGTH(date_of_interaction)>='10' 
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(b.date_of_interaction1 as date))
from PRM.mgage_tier3 a inner join GAIN_THEORY.PRMActiveInactiveDateMapping b
on a.date_of_interaction=b.date_of_interaction
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on a.Brand_name=c.Brand_name
where LENGTH(a.date_of_interaction)<'10'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

----thinkwalnut tier 3

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(date_of_interaction,7,4)||'-'||SUBSTR(date_of_interaction,4,2)||'-'||SUBSTR(date_of_interaction,1,2) as date))
from PRM.thinkwalnut_tier3  a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where date_of_interaction like '%-%' and LENGTH(date_of_interaction)>='10'
and date_of_interaction not like '%0000-00-00%'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(SUBSTR(date_of_interaction,7,4)||'-'||SUBSTR(date_of_interaction,4,2)||'-'||SUBSTR(date_of_interaction,1,2) as date))
from PRM.thinkwalnut_tier3  a
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping b on a.Brand_name=b.Brand_name
where date_of_interaction like '%/%' and LENGTH(date_of_interaction)>='10'
and (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;








--imi tier 4
insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.imimobile_tier4_obd_master a 
inner join PRM.imimobile_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.imimobile_tier4_sms_master  a 
inner join PRM.imimobile_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--dl197 tier 4
insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.dl197_tier4_obd_Master a 
inner join PRM.dl197_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.dl197_tier4_sms_master  a 
inner join PRM.dl197_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--dloz tier 4

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.DLOZ_tier4_obd_master a 
inner join PRM.DLOZ_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.DLOZ_tier4_sms_master  a 
inner join PRM.DLOZ_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--dlvv tier 4

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.DLVV_tier4_obd_master a 
inner join PRM.DLVV_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.DLVV_tier4_sms_master  a 
inner join PRM.DLVV_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--KNOWLARITY

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.KNOWLARITY_tier4_obd_master a 
inner join PRM.KNOWLARITY_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.KNOWLARITY_tier4_sms_master  a 
inner join PRM.KNOWLARITY_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--MELTAG

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.MELTAG_tier4_OBD_Master a 
inner join PRM.MELTAG_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.MELTAG_tier4_SMS_MASTER  a 
inner join PRM.MELTAG_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--MGAGE

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(a.Date_Time_Interaction as date))
from PRM.MGAGE_tier4_obd_master a 
inner join PRM.MGAGE_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(date_and_time_of_interaction as date))
from PRM.MGAGE_tier4_sms_master  a 
inner join PRM.MGAGE_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on b.Brand=c.Brand_name
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

--thinkwalnut

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(substr(Date_Time_Interaction,7,4)||'-'||substr(Date_Time_Interaction,4,2)||'-'||substr(Date_Time_Interaction,1,2) as date))
from PRM.thinkwalnut_tier4_obd_master a 
inner join PRM.thinkwalnut_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on lower(b.Brand)=lower(c.Brand_name)
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;

insert into "GAIN_THEORY".IN0405_data
(best_mobile_number_hash ,source,Updatedbrand_name,lastinteractiondate)
select distinct best_mobile_number_hash ,'DL',updatedbrand_name
,max(cast(substr(date_and_time_of_interaction,7,4)||'-'||substr(date_and_time_of_interaction,4,2)||'-'||substr(date_and_time_of_interaction,1,2) as date))
from PRM.thinkwalnut_tier4_sms_master  a 
inner join PRM.thinkwalnut_tier4_campaign_master b on a.campaign_id=b.campaign_id
inner join GAIN_THEORY.PRMActiveInactiveBrandMapping c on lower(b.Brand)=lower(c.Brand_name)
where  (lower(updatedbrand_name) like '%close%' or lower(updatedbrand_name) like '%corne%' or lower(updatedbrand_name) like '%pond%' or lower(updatedbrand_name) like '%sunsi%')
group by best_mobile_number_hash,updatedbrand_name;




update "GAIN_THEORY".IN0405_data
from (select distinct mobile_number,gender from GAIN_THEORY.PRMDashboard_data) tab
set gender = tab.gender 
where best_mobile_number_hash = tab.mobile_number;






