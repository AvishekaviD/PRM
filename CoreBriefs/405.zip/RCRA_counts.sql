select campaign_name,count(distinct best_mobile_number_hash)
from (select distinct b.campaign_name,best_mobile_number_hash from PRM.DLOZ_tier4_obd_master a 
inner join PRM.DLOZ_tier4_campaign_master b
on a.campaign_id = b.campaign_id where a.campaign_id = 'IN0114'
union all select distinct b.campaign_name,best_mobile_number_hash from PRM.DLOZ_tier4_sms_master a 
inner join PRM.DLOZ_tier4_campaign_master b
on a.campaign_id = b.campaign_id where a.campaign_id = 'IN0114') a
group by 1;

select campaign_name,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency,count(distinct best_mobile_number_hash) counts
from (select distinct campaign_name,best_mobile_number_hash,max(lastinetractiondate) lastinetractiondate
from  (select distinct b.campaign_name,a.best_mobile_number_hash,cast(a.Date_Time_Interaction as date) lastinetractiondate
from PRM.DLOZ_tier4_obd_master a inner join PRM.DLOZ_tier4_campaign_master b
on a.campaign_id = b.campaign_id where a.campaign_id = 'IN0114'
union all 
select distinct b.campaign_name,a.best_mobile_number_hash,cast(a.DATE_AND_TIME_OF_INTERACTION as date) lastinetractiondate
from PRM.DLOZ_tier4_sms_master a inner join PRM.DLOZ_tier4_campaign_master b
on a.campaign_id = b.campaign_id where a.campaign_id = 'IN0114') a
group by 1,2) a
group by 1,2;




