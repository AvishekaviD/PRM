



--brands FAL,Cornetto,Closeup,Ponds and sunsilk

select brand,lsm,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency,count(distinct mobile_number)
from (select brand,lsm,mobile_number,max(lastinetractiondate) lastinetractiondate from GAIN_THEORY.PRMDashboard_data
group by brand,lsm,mobile_number) a
where (lower(brand) like '%fair%') and lsm in ('0-3','7+','4-7') 
group by 1,2,3

union all

select brand,'0-3' lsm,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency
,count(distinct a.best_mobile_number_hash)
from  (select best_mobile_number_hash,gender,case when lower(UpdatedBrand_Name) like '%close%' then 'Close UP'
when lower(UpdatedBrand_Name) like '%corne%' then 'Cornetto' when lower(UpdatedBrand_Name) like '%sun%' then 'Sunsilk'
when lower(UpdatedBrand_Name) like '%pond%' then 'Ponds' end as brand,max(lastinteractiondate) lastinetractiondate 
from "GAIN_THEORY".IN0405_data
group by 1,2,3) a inner join GAIN_THEORY.LSM3_CombinedSourceSKU b
on a.best_mobile_number_hash = b.best_mobile_number_hash
where b.FinalLSM = '0-3'
group by 1,2,3

union all

select brand,'4-7' lsm,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency
,count(distinct a.best_mobile_number_hash)
from  (select best_mobile_number_hash,gender,case when lower(UpdatedBrand_Name) like '%close%' then 'Close UP'
when lower(UpdatedBrand_Name) like '%corne%' then 'Cornetto' when lower(UpdatedBrand_Name) like '%sun%' then 'Sunsilk'
when lower(UpdatedBrand_Name) like '%pond%' then 'Ponds' end as brand,max(lastinteractiondate) lastinetractiondate 
from "GAIN_THEORY".IN0405_data
group by 1,2,3) a inner join GAIN_THEORY.LSM3_CombinedSourceSKU b
on a.best_mobile_number_hash = b.best_mobile_number_hash
where b.FinalLSM = '4-7'
group by 1,2,3

union all

select brand,'7+' lsm,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency
,count(distinct a.best_mobile_number_hash)
from  (select best_mobile_number_hash,gender,case when lower(UpdatedBrand_Name) like '%close%' then 'Close UP'
when lower(UpdatedBrand_Name) like '%corne%' then 'Cornetto' when lower(UpdatedBrand_Name) like '%sun%' then 'Sunsilk'
when lower(UpdatedBrand_Name) like '%pond%' then 'Ponds' end as brand,max(lastinteractiondate) lastinetractiondate 
from "GAIN_THEORY".IN0405_data
group by 1,2,3) a inner join GAIN_THEORY.LSM3_CombinedSourceSKU b
on a.best_mobile_number_hash = b.best_mobile_number_hash
where b.FinalLSM = '7+'
group by 1,2,3;



select gender,lsm,case when current_date -lastinetractiondate <= 90 then 'less than 3 months'
when current_date -lastinetractiondate > 90 and current_date -lastinetractiondate <= 180 then '3-6 months'
when current_date -lastinetractiondate > 180 and current_date -lastinetractiondate <= 270 then '6-9 months'
when current_date -lastinetractiondate > 270 and current_date -lastinetractiondate <= 365 then '9-12 months'
when current_date -lastinetractiondate > 365 then 'greater than 12 months'
else 'greater than 12 months' end as recency,count(distinct mobile_number)
from (select gender,lsm,mobile_number,max(lastinetractiondate) lastinetractiondate from GAIN_THEORY.PRMDashboard_data
group by gender,lsm,mobile_number) a
where lsm in ('0-3','7+','4-7') 
group by 1,2,3;


